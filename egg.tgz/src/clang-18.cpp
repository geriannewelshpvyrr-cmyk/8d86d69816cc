// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clang 18\n", stdout);
  return lionss_run_workload("clang-18");
}
