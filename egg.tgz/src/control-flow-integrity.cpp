// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("control flow integrity\n", stdout);
  return lionss_run_workload("control-flow-integrity");
}
